<?php

namespace PhonebookBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PhonebookBundle extends Bundle
{
}
